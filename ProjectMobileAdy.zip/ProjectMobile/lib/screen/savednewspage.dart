import 'dart:html';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:news_app/model/model.dart';
import 'package:news_app/model/saved_news.dart';
import 'package:news_app/screen/detailpage.dart';
import 'package:news_app/widget/news_item.dart';

class SavedNewsPage extends StatefulWidget {
  const SavedNewsPage({Key? key}) : super(key: key);

  @override
  _SavedNewsPageState createState() => _SavedNewsPageState();
}

class _SavedNewsPageState extends State<SavedNewsPage> {
  Box<SavedNews> localDB = Hive.box<SavedNews>("savedNews_list");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          "Saved News"
        ),
      ),
      body: ValueListenableBuilder(
        valueListenable: localDB.listenable(),
        builder: (BuildContext context, Box<dynamic> value, Widget? child){
          if(value.isEmpty){
            return Center(
              child: Text('Favorite Manga listing is Empty'),
            );
          } else {
            return _listNewsSaved(localDB as List<Article>);
          }
        },
      ),
    );
  }

  Widget _listNewsSaved(List<Article> article) {
    return Container(
      height: MediaQuery
          .of(context)
          .size
          .height,
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      child: ListView.builder(
        itemBuilder: (context, index) => NewsItem(article: article[index]),
        itemCount: article.length,
      ),
    );
  }
}
